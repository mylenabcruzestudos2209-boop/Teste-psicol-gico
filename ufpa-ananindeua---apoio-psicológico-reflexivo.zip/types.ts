
export enum PrognosisType {
  AUTOCONHECIMENTO = "Autoconhecimento fortalecido",
  EQUILIBRIO = "Equilíbrio emocional",
  ATENCAO = "Atenção emocional",
  SOBRECARGA = "Sobrecarga emocional",
  REFLEXAO = "Necessidade de reflexão guiada"
}

export enum QuestionType {
  SCALE = "scale",
  CHOICE = "choice",
  MULTI = "multi",
  TEXT = "text"
}

export interface Question {
  id: number;
  type: QuestionType;
  text: string;
  options?: string[];
}

export interface UserResponse {
  questionId: number;
  value: string | string[];
  score?: number;
}

export interface AnalysisResult {
  prognosis: PrognosisType;
  aiFeedback: string;
  activities: string[];
  percentage: number;
  parameter: string;
}

export interface StoredResult {
  date: string;
  prognosis: PrognosisType;
  percentage: number;
  factors: string[];
  suggestion: string;
}
