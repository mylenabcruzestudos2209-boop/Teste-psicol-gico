
import { Question, QuestionType, PrognosisType } from './types';

export const QUESTIONS: Question[] = [
  { id: 1, type: QuestionType.SCALE, text: "Com que frequência você se sente sobrecarregado(a) com as atividades acadêmicas?", options: ["Nunca", "Raramente", "Às vezes", "Frequentemente", "Sempre"] },
  { id: 2, type: QuestionType.SCALE, text: "Você sente dificuldade em conciliar os estudos com outras áreas da sua vida?", options: ["Nenhuma", "Pouca", "Moderada", "Alta", "Muito alta"] },
  { id: 3, type: QuestionType.SCALE, text: "Com que frequência você sente ansiedade relacionada ao desempenho acadêmico?", options: ["Nunca", "Raramente", "Às vezes", "Frequentemente", "Sempre"] },
  { id: 4, type: QuestionType.CHOICE, text: "Você sente pressão excessiva para obter bons resultados acadêmicos?", options: ["Não", "Pouca pressão", "Moderada", "Muita pressão"] },
  { id: 5, type: QuestionType.SCALE, text: "Já pensou em desistir do curso por questões emocionais ou psicológicas?", options: ["Nunca", "Raramente", "Às vezes", "Frequentemente"] },
  { id: 6, type: QuestionType.SCALE, text: "Como você avalia sua saúde mental atualmente?", options: ["Muito ruim", "Ruim", "Regular", "Boa", "Muito boa"] },
  { id: 7, type: QuestionType.SCALE, text: "Com que frequência você se sente desmotivado(a) para assistir aulas ou realizar atividades?", options: ["Nunca", "Raramente", "Às vezes", "Frequentemente", "Sempre"] },
  { id: 8, type: QuestionType.SCALE, text: "Você sente dificuldade de concentração durante aulas ou estudos?", options: ["Nunca", "Raramente", "Às vezes", "Frequentemente", "Sempre"] },
  { id: 9, type: QuestionType.SCALE, text: "Com que frequência você sente cansaço extremo ou esgotamento mental?", options: ["Nunca", "Raramente", "Às vezes", "Frequentemente", "Sempre"] },
  { id: 10, type: QuestionType.CHOICE, text: "Você sente que possui apoio emocional suficiente dentro da universidade?", options: ["Sim, totalmente", "Parcialmente", "Pouco", "Sempre"] },
  { id: 11, type: QuestionType.CHOICE, text: "Você conhece os serviços de apoio psicológico oferecidos pela universidade?", options: ["Sim e já utilizei", "Sim, mas nunca utilizei", "Não conheço"] },
  { id: 12, type: QuestionType.CHOICE, text: "Caso precise de ajuda, você se sentiria confortável em buscar apoio institucional?", options: ["Sim", "Talvez", "Não"] },
  { id: 13, type: QuestionType.MULTI, text: "Quais fatores mais impactam negativamente sua saúde mental na universidade?", options: ["Carga excessiva de disciplinas", "Pressão por desempenho", "Problemas financeiros", "Dificuldades familiares", "Falta de apoio emocional", "Outro"] },
  { id: 14, type: QuestionType.CHOICE, text: "Você acredita que a universidade poderia adotar mais ações voltadas à saúde mental?", options: ["Sim", "Não", "Não sei"] },
  { id: 15, type: QuestionType.TEXT, text: "Na sua opinião, quais medidas poderiam melhorar a saúde mental dos discentes?" }
];

export const PROGNOSIS_EXPLANATIONS: Record<PrognosisType, string> = {
  [PrognosisType.AUTOCONHECIMENTO]: "Indica que você possui uma base sólida de percepção sobre suas emoções e limites. Suas ferramentas internas de enfrentamento estão bem desenvolvidas, permitindo uma jornada acadêmica mais resiliente.",
  [PrognosisType.EQUILIBRIO]: "Você apresenta uma boa gestão emocional, mas há pontos de oscilação. É um estado saudável que exige manutenção preventiva através de pausas e atividades de lazer constantes.",
  [PrognosisType.ATENCAO]: "Sinaliza que o ambiente acadêmico está começando a cobrar um preço emocional. É um convite para desacelerar e observar quais áreas da sua vida estão sendo negligenciadas em prol dos estudos.",
  [PrognosisType.SOBRECARGA]: "Indica um nível elevado de estresse e fadiga mental. Suas reservas de energia estão baixas, o que pode afetar sua concentração e humor. É fundamental buscar apoio e reorganizar prioridades.",
  [PrognosisType.REFLEXAO]: "Sugere que você está em um momento de profunda vulnerabilidade emocional. Sentimentos de desamparo ou confusão podem estar presentes. A busca por orientação profissional e redes de apoio é altamente recomendada."
};

export const LEISURE_SUGGESTIONS = [
  { title: "Lazer Contemplativo", items: ["Visita ao Parque Zoobotânico para contato com a natureza", "Observação do pôr do sol na orla", "Prática de fotografia amadora dos detalhes do campus"] },
  { title: "Lazer Social", items: ["Organizar um piquenique leve com colegas de curso", "Participar de grupos de discussão sobre temas não acadêmicos", "Jogos de tabuleiro ou cartas em momentos de pausa"] },
  { title: "Lazer Criativo", items: ["Pintura em aquarela ou desenho livre", "Cozinhar uma receita nova e prazerosa", "Escrita de contos ou poesias para expressar emoções"] },
  { title: "Lazer Ativo", items: ["Prática de esportes coletivos leves", "Yoga ou alongamento consciente no início do dia", "Ciclismo por rotas arborizadas de Ananindeua"] }
];

export const getAnalysisData = (responses: any[]) => {
  const scaleResponses = responses.filter(r => r.score !== undefined).slice(0, 9);
  const avg = scaleResponses.reduce((acc, curr) => acc + curr.score, 0) / (scaleResponses.length || 1);
  
  const wellnessPercentage = Math.round(((5 - avg) / (5 - 1)) * 100);

  let prognosis: PrognosisType;
  let parameter: string;

  if (avg <= 1.5) {
    prognosis = PrognosisType.AUTOCONHECIMENTO;
    parameter = "Nível Ótimo de Estabilidade";
  } else if (avg <= 2.5) {
    prognosis = PrognosisType.EQUILIBRIO;
    parameter = "Nível Satisfatório de Estabilidade";
  } else if (avg <= 3.5) {
    prognosis = PrognosisType.ATENCAO;
    parameter = "Nível Moderado de Vulnerabilidade";
  } else if (avg <= 4.5) {
    prognosis = PrognosisType.SOBRECARGA;
    parameter = "Nível Alto de Vulnerabilidade";
  } else {
    prognosis = PrognosisType.REFLEXAO;
    parameter = "Estado de Alerta Crítico";
  }

  return { prognosis, wellnessPercentage, parameter };
};

export const getPrognosis = (responses: any[]): PrognosisType => {
  return getAnalysisData(responses).prognosis;
};

// Link atualizado para a DAEST (Diretoria de Assistência Estudantil)
export const PSYCHOLOGIST_LINK = "https://daest.ufpa.br/";

export const RELAXATION_ACTIVITIES = [
  "Prática de respiração guiada de 5 minutos.",
  "Pausa para um chá e observação do ambiente no Campus Ananindeua.",
  "Escrita livre sobre seus sentimentos de hoje.",
  "Caminhada leve ouvindo sua música favorita.",
  "Exercício de alongamento focado no pescoço e ombros.",
  "Meditação rápida para foco acadêmico."
];
