import React, { useState, useEffect } from 'react';
import { QUESTIONS, getAnalysisData, RELAXATION_ACTIVITIES, PSYCHOLOGIST_LINK, PROGNOSIS_EXPLANATIONS, LEISURE_SUGGESTIONS } from './constants';
import { UserResponse, AnalysisResult, QuestionType, StoredResult, PrognosisType } from './types';
import { analyzeEmotionalState } from './services/geminiService';
import { 
  Heart, 
  Brain, 
  ArrowRight, 
  RefreshCcw, 
  ExternalLink, 
  Sparkles,
  ShieldCheck,
  GraduationCap,
  ChevronLeft,
  CheckCircle2,
  Coffee,
  Sun,
  Palette,
  Users,
  Info,
  Activity,
  BarChart3,
  MessageSquare,
  AlertTriangle,
  ArrowLeft
} from 'lucide-react';

const App: React.FC = () => {
  const [step, setStep] = useState<'welcome' | 'form' | 'loading' | 'results' | 'dashboard'>('welcome');
  const [responses, setResponses] = useState<UserResponse[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [tempMulti, setTempMulti] = useState<string[]>([]);
  const [tempText, setTempText] = useState("");
  const [history, setHistory] = useState<StoredResult[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('canan_mental_health_history');
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  const saveToHistory = (result: AnalysisResult, userResponses: UserResponse[]) => {
    const factors = userResponses.find(r => r.questionId === 13)?.value as string[] || [];
    const suggestion = userResponses.find(r => r.questionId === 15)?.value as string || "";
    
    const newEntry: StoredResult = {
      date: new Date().toISOString(),
      prognosis: result.prognosis,
      percentage: result.percentage,
      factors,
      suggestion
    };

    const newHistory = [...history, newEntry];
    setHistory(newHistory);
    localStorage.setItem('canan_mental_health_history', JSON.stringify(newHistory));
  };

  const Header = () => (
    <header className="w-full bg-white border-b border-slate-200 py-6 px-4 md:px-8 mb-8 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Lado Esquerdo: Identidade do Campus */}
        <div className="flex items-center gap-3 md:gap-4 shrink-0">
          <div className="flex flex-col items-center md:items-start cursor-pointer" onClick={() => setStep('welcome')}>
            <span className="text-3xl md:text-4xl font-serif font-bold text-indigo-900 leading-none tracking-tighter">CANAN</span>
            <span className="text-[10px] text-slate-400 uppercase tracking-[0.2em] font-bold">Campus Ananindeua</span>
          </div>
        </div>

        {/* Centro: Título do App */}
        <div className="flex flex-col items-center text-center cursor-pointer flex-1 px-2" onClick={() => setStep('welcome')}>
          <h1 className="text-lg md:text-2xl font-serif font-bold text-indigo-950 tracking-tight leading-tight">
            Saúde mental dos discentes- Prognóstico
          </h1>
          <p className="hidden md:block text-[10px] text-slate-500 font-serif italic mt-1 uppercase tracking-widest">
            Apoio Psicológico Reflexivo
          </p>
        </div>

        {/* Lado Direito: Identidade Textual UFPA */}
        <div className="flex items-center gap-3 md:gap-4 shrink-0">
          <div className="text-right">
            <p className="text-[10px] md:text-xs font-serif italic text-slate-400 leading-tight uppercase">
              UFPA<br/>
              <span className="font-bold text-slate-500 uppercase tracking-tighter">Ananindeua</span>
            </p>
          </div>
        </div>
      </div>
    </header>
  );

  const handleNext = (val?: any, score?: number) => {
    const q = QUESTIONS[currentIdx];
    let finalValue = val;
    if (q.type === QuestionType.MULTI) finalValue = tempMulti;
    if (q.type === QuestionType.TEXT) finalValue = tempText;

    const newResponse: UserResponse = {
      questionId: q.id,
      value: finalValue,
      score: score
    };

    const updated = [...responses];
    updated[currentIdx] = newResponse;
    setResponses(updated);
    
    setTempMulti([]);
    setTempText("");

    if (currentIdx < QUESTIONS.length - 1) {
      setCurrentIdx(currentIdx + 1);
    } else {
      process(updated);
    }
  };

  const process = async (finalData: UserResponse[]) => {
    setStep('loading');
    const { prognosis, wellnessPercentage, parameter } = getAnalysisData(finalData);
    const feedback = await analyzeEmotionalState(finalData, prognosis);
    const result: AnalysisResult = {
      prognosis,
      aiFeedback: feedback,
      activities: RELAXATION_ACTIVITIES.sort(() => 0.5 - Math.random()).slice(0, 3),
      percentage: wellnessPercentage,
      parameter: parameter
    };
    setAnalysis(result);
    saveToHistory(result, finalData);
    setStep('results');
  };

  if (step === 'welcome') {
    return (
      <div className="min-h-screen flex flex-col bg-[#b3ebf2]">
        <Header />
        <main className="flex-1 flex flex-col items-center justify-center p-6 gap-8">
          <div className="max-w-2xl w-full bg-white rounded-3xl shadow-xl p-8 border border-slate-100">
            <div className="flex justify-center mb-6">
               <div className="bg-pastel-blue p-4 rounded-full">
                 <Brain size={48} className="text-indigo-600" />
               </div>
            </div>
            <h2 className="text-3xl font-serif text-center text-slate-800 mb-6">Acolhimento e Reflexão</h2>
            
            <div className="bg-pastel-rose border-l-4 border-rose-300 p-4 mb-8 rounded-r-lg">
              <div className="flex items-center gap-2 text-rose-900 font-bold mb-1 italic">
                <ShieldCheck size={20} /> Compromisso Ético e Legal
              </div>
              <p className="text-sm text-rose-800 leading-relaxed font-serif">
                Suas respostas são confidenciais e destinadas apenas à sua autoanálise assistida. 
                Este sistema foi construído respeitando os princípios éticos de saúde mental e a LGPD.
              </p>
            </div>

            <div className="space-y-4 mb-10 text-slate-600 font-serif text-lg">
              <p>Este questionário visa identificar fatores acadêmicos, emocionais e sociais que impactam sua vida na universidade.</p>
              <p>Ao final, você receberá uma análise personalizada via IA, sua porcentagem de bem-estar e sugestões de lazer.</p>
            </div>

            <button 
              onClick={() => { setResponses([]); setCurrentIdx(0); setStep('form'); }}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg font-serif"
            >
              Iniciar Questionário <ArrowRight size={20} />
            </button>
          </div>

          <button 
            onClick={() => setStep('dashboard')}
            className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-serif italic text-sm transition-colors border-b border-transparent hover:border-indigo-600"
          >
            <BarChart3 size={16} /> Ver Painel de Análise (Acesso Institucional)
          </button>
        </main>
      </div>
    );
  }

  if (step === 'dashboard') {
    const total = history.length;
    const avgWellness = total > 0 ? Math.round(history.reduce((acc, curr) => acc + curr.percentage, 0) / total) : 0;
    
    const progDist = Object.values(PrognosisType).map(type => ({
      label: type,
      count: history.filter(h => h.prognosis === type).length,
      percentage: total > 0 ? (history.filter(h => h.prognosis === type).length / total) * 100 : 0
    }));

    const factorCounts: Record<string, number> = {};
    history.forEach(h => h.factors.forEach(f => {
      factorCounts[f] = (factorCounts[f] || 0) + 1;
    }));
    const sortedFactors = Object.entries(factorCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);

    return (
      <div className="min-h-screen flex flex-col bg-[#b3ebf2] pb-20">
        <Header />
        <div className="max-w-5xl mx-auto w-full p-6 space-y-8">
          <div className="flex items-center justify-between">
            <button onClick={() => setStep('welcome')} className="flex items-center gap-2 text-slate-600 hover:text-indigo-600 font-serif italic">
              <ArrowLeft size={18} /> Voltar ao Início
            </button>
            <h2 className="text-3xl font-serif text-slate-800">Painel de Monitoramento CANAN</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm text-center">
              <span className="text-slate-400 text-xs font-bold uppercase tracking-widest block mb-2">Total de Participantes</span>
              <span className="text-4xl font-serif font-bold text-indigo-900">{total}</span>
            </div>
            <div className="bg-pastel-blue/30 p-6 rounded-3xl border border-pastel-blue shadow-sm text-center">
              <span className="text-indigo-600 text-xs font-bold uppercase tracking-widest block mb-2">Média de Bem-estar</span>
              <span className="text-4xl font-serif font-bold text-indigo-900">{avgWellness}%</span>
            </div>
            <div className="bg-pastel-rose/40 p-6 rounded-3xl border border-pastel-rose shadow-sm text-center">
              <span className="text-rose-600 text-xs font-bold uppercase tracking-widest block mb-2">Nível de Alerta</span>
              <span className="text-2xl font-serif font-bold text-rose-900">
                {avgWellness < 50 ? "Crítico" : avgWellness < 75 ? "Atenção" : "Estável"}
              </span>
            </div>
            <div className="bg-pastel-green/30 p-6 rounded-3xl border border-pastel-green shadow-sm text-center">
              <span className="text-emerald-600 text-xs font-bold uppercase tracking-widest block mb-2">Engajamento</span>
              <span className="text-4xl font-serif font-bold text-emerald-900">Alto</span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
              <h3 className="text-xl font-serif font-bold text-slate-800 mb-6 flex items-center gap-2">
                <Activity size={20} className="text-indigo-400" /> Distribuição de Prognósticos
              </h3>
              <div className="space-y-4">
                {progDist.map((item, i) => (
                  <div key={i} className="space-y-1">
                    <div className="flex justify-between text-sm font-serif">
                      <span className="text-slate-600">{item.label}</span>
                      <span className="font-bold text-slate-800">{item.count} ({Math.round(item.percentage)}%)</span>
                    </div>
                    <div className="w-full h-2 bg-slate-50 rounded-full overflow-hidden">
                      <div className="h-full bg-pastel-blue transition-all duration-500" style={{ width: `${item.percentage}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
              <h3 className="text-xl font-serif font-bold text-slate-800 mb-6 flex items-center gap-2">
                <AlertTriangle size={20} className="text-amber-400" /> Principais Fatores Críticos
              </h3>
              <div className="space-y-4">
                {sortedFactors.length > 0 ? sortedFactors.map(([factor, count], i) => (
                  <div key={i} className="flex items-center gap-4 bg-pastel-yellow/20 p-3 rounded-xl border border-pastel-yellow/40">
                    <span className="w-8 h-8 rounded-full bg-pastel-yellow flex items-center justify-center font-bold text-amber-800 text-xs">{i+1}</span>
                    <span className="flex-1 font-serif text-slate-700">{factor}</span>
                    <span className="font-bold text-amber-900">{count} votos</span>
                  </div>
                )) : <p className="text-slate-400 italic text-center font-serif">Sem dados suficientes ainda.</p>}
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="text-xl font-serif font-bold text-slate-800 mb-6 flex items-center gap-2">
              <MessageSquare size={20} className="text-pastel-blue" /> Mural de Sugestões (Voz Discente)
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {history.filter(h => h.suggestion).length > 0 ? history.filter(h => h.suggestion).map((h, i) => (
                <div key={i} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 italic font-serif text-slate-600 text-sm leading-relaxed">
                  "{h.suggestion}"
                </div>
              )) : <p className="col-span-full text-slate-400 italic text-center font-serif">Aguardando as primeiras contribuições dos alunos.</p>}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (step === 'form') {
    const q = QUESTIONS[currentIdx];
    const progress = ((currentIdx + 1) / QUESTIONS.length) * 100;
    return (
      <div className="min-h-screen flex flex-col bg-[#b3ebf2]">
        <Header />
        <div className="max-w-2xl mx-auto w-full p-6">
          <div className="mb-8 flex items-center justify-between">
            <button disabled={currentIdx === 0} onClick={() => setCurrentIdx(currentIdx - 1)} className="text-slate-500 hover:text-indigo-600 disabled:opacity-0 flex items-center gap-1 font-serif">
              <ChevronLeft size={20} /> Voltar
            </button>
            <div className="text-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Questão {currentIdx + 1} de {QUESTIONS.length}</span>
              <div className="w-32 h-1 bg-slate-200 rounded-full mt-1 overflow-hidden">
                <div className="h-full bg-pastel-blue transition-all duration-300" style={{width: `${progress}%`}} />
              </div>
            </div>
            <div className="w-10"></div>
          </div>
          <div className="bg-white rounded-3xl shadow-lg p-8 border border-slate-50 min-h-[400px] flex flex-col justify-center">
            <h3 className="text-2xl font-serif text-slate-800 mb-10 leading-tight">{q.text}</h3>
            <div className="space-y-3">
              {q.type === QuestionType.SCALE && q.options?.map((opt, i) => (
                <button key={i} onClick={() => handleNext(opt, i + 1)} className="w-full p-4 rounded-xl text-left font-serif text-lg bg-pastel-blue/40 border border-transparent hover:border-pastel-blue hover:bg-pastel-blue transition-all text-indigo-900 group flex justify-between items-center">
                  {opt} <span className="opacity-0 group-hover:opacity-100 transition-opacity"><ArrowRight size={18} /></span>
                </button>
              ))}
              {q.type === QuestionType.CHOICE && q.options?.map((opt, i) => (
                <button key={i} onClick={() => handleNext(opt)} className="w-full p-4 rounded-xl text-left font-serif text-lg bg-pastel-green/40 border border-transparent hover:border-pastel-green hover:bg-pastel-green transition-all text-emerald-900 group flex justify-between items-center">
                  {opt} <span className="opacity-0 group-hover:opacity-100 transition-opacity"><ArrowRight size={18} /></span>
                </button>
              ))}
              {q.type === QuestionType.MULTI && (
                <div className="space-y-3">
                  {q.options?.map((opt, i) => (
                    <div key={i} onClick={() => setTempMulti(prev => prev.includes(opt) ? prev.filter(x => x !== opt) : [...prev, opt])} className={`p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${tempMulti.includes(opt) ? 'bg-pastel-yellow border-amber-300' : 'bg-pastel-yellow/40 border-transparent hover:bg-pastel-yellow'}`}>
                      <span className="font-serif text-amber-900">{opt}</span> {tempMulti.includes(opt) && <CheckCircle2 size={18} className="text-amber-600" />}
                    </div>
                  ))}
                  <button disabled={tempMulti.length === 0} onClick={() => handleNext()} className="w-full mt-6 bg-amber-500 text-white py-4 rounded-xl disabled:opacity-50 font-bold shadow-md hover:bg-amber-600 transition-colors font-serif">
                    Confirmar Seleção
                  </button>
                </div>
              )}
              {q.type === QuestionType.TEXT && (
                <div className="space-y-4">
                  <textarea value={tempText} onChange={(e) => setTempText(e.target.value)} placeholder="Compartilhe sua opinião sobre o que pode ser melhorado..." className="w-full h-40 p-4 rounded-2xl bg-slate-50 border border-slate-200 font-serif text-lg focus:ring-2 focus:ring-indigo-100 outline-none" />
                  <button onClick={() => handleNext()} className="w-full bg-slate-800 text-white py-4 rounded-xl font-bold shadow-md hover:bg-slate-700 transition-colors font-serif">
                    Finalizar e Gerar Relatório
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (step === 'loading') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#b3ebf2] p-6 text-center">
        <RefreshCcw size={48} className="animate-spin text-indigo-400 mb-6" />
        <h2 className="text-2xl font-serif text-slate-700 italic">O Campus Ananindeua valoriza sua voz.</h2>
        <p className="text-slate-500 mt-2 font-serif">Nossa IA está lendo suas respostas para uma análise cuidadosa...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#b3ebf2] pb-20">
      <Header />
      <div className="max-w-4xl mx-auto p-6 space-y-12">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8 text-center space-y-6">
          <Sparkles size={40} className="text-pastel-yellow mx-auto mb-4 stroke-slate-400 fill-pastel-yellow" />
          <h2 className="text-3xl font-serif text-slate-800 mb-2">Relatório de Autocuidado</h2>
          <div className="flex flex-col md:flex-row gap-4 justify-center items-stretch">
            <div className="bg-pastel-blue/30 rounded-2xl p-6 border border-pastel-blue flex-1 flex flex-col justify-center">
               <span className="text-xs uppercase font-bold text-indigo-400 mb-1 tracking-widest">Bem-estar Emocional</span>
               <span className="text-5xl font-serif font-bold text-indigo-900">{analysis?.percentage}%</span>
            </div>
            <div className="bg-pastel-green/30 rounded-2xl p-6 border border-pastel-green flex-1 flex flex-col justify-center">
               <span className="text-xs uppercase font-bold text-emerald-600 mb-1 tracking-widest">Parâmetro de Análise</span>
               <span className="text-xl font-serif font-bold text-emerald-900">{analysis?.parameter}</span>
            </div>
          </div>
          <div className="inline-block px-8 py-3 bg-pastel-yellow text-amber-900 rounded-full font-bold border border-pastel-yellow shadow-sm text-lg font-serif">
            Prognóstico: {analysis?.prognosis}
          </div>
          <div className="mt-8 max-w-2xl mx-auto p-6 bg-slate-50 rounded-2xl border border-slate-100 text-left">
            <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2 font-serif"><Info size={14} /> Entenda seu Prognóstico</h4>
            <p className="font-serif text-slate-700 italic leading-relaxed">{analysis ? PROGNOSIS_EXPLANATIONS[analysis.prognosis] : ''}</p>
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 bg-pastel-blue/20 rounded-3xl p-8 border border-pastel-blue/40 font-serif">
            <h3 className="text-xl font-bold text-indigo-800 mb-6 flex items-center gap-2"><Brain size={22} /> Percepção Assistida por IA</h3>
            <div className="text-indigo-900 text-lg leading-relaxed whitespace-pre-wrap italic bg-white/60 p-6 rounded-2xl border border-pastel-blue/30 shadow-inner">{analysis?.aiFeedback}</div>
          </div>
          <div className="space-y-6">
            <div className="bg-pastel-rose rounded-3xl p-6 border border-pastel-rose">
              <h3 className="font-bold text-rose-900 mb-4 flex items-center gap-2"><Coffee size={18} /> Pausas Imediatas</h3>
              <ul className="space-y-3">
                {analysis?.activities.map((act, i) => (
                  <li key={i} className="text-sm text-rose-800 border-b border-rose-200/50 pb-2 last:border-0 italic flex gap-2"><span className="font-bold">•</span> {act}</li>
                ))}
              </ul>
            </div>
            <div className="bg-white rounded-3xl p-6 border border-slate-200 text-center shadow-sm">
              <p className="text-xs text-slate-500 mb-4 uppercase font-bold tracking-tighter">Apoio Institucional (DAEST)</p>
              <a href={PSYCHOLOGIST_LINK} target="_blank" className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-md w-full justify-center font-serif">
                Acessar Portal DAEST <ExternalLink size={14} />
              </a>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8">
          <div className="flex items-center gap-3 mb-8 border-b border-slate-100 pb-4">
            <Sun className="text-pastel-yellow stroke-slate-400 fill-pastel-yellow" size={28} />
            <h3 className="text-2xl font-serif text-slate-800">Sugestões de Lazer para o Bem-estar</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {LEISURE_SUGGESTIONS.map((category, idx) => {
              const Icons = [Sun, Users, Palette, Activity];
              const Icon = Icons[idx % Icons.length];
              const colors = ["bg-pastel-yellow/30 text-amber-900 border-pastel-yellow", "bg-pastel-blue/30 text-indigo-900 border-pastel-blue", "bg-pastel-green/30 text-emerald-900 border-pastel-green", "bg-pastel-rose text-rose-900 border-pastel-rose"];
              return (
                <div key={idx} className={`p-6 rounded-2xl border ${colors[idx]}`}>
                  <h4 className="font-bold flex items-center gap-2 mb-4 font-serif"><Icon size={18} /> {category.title}</h4>
                  <ul className="space-y-2 text-sm italic font-serif">
                    {category.items.map((item, i) => (
                      <li key={i} className="flex gap-2"><span className="opacity-50">•</span> {item}</li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
        <div className="flex flex-col items-center gap-4 pt-12 border-t border-slate-100">
          <div className="flex flex-col md:flex-row gap-4 w-full max-w-lg">
            <button 
              onClick={() => setStep('welcome')} 
              className="flex-1 flex items-center justify-center gap-2 bg-white border border-slate-200 text-slate-600 px-6 py-4 rounded-2xl hover:bg-slate-50 transition-all font-serif italic shadow-sm"
            >
              <RefreshCcw size={16} /> Nova Reflexão
            </button>
            <button 
              onClick={() => setStep('dashboard')} 
              className="flex-1 flex items-center justify-center gap-2 bg-pastel-blue text-indigo-900 px-6 py-4 rounded-2xl hover:bg-pastel-blue/80 transition-all font-serif font-bold shadow-md"
            >
              <BarChart3 size={16} /> Ver Dashboard das Respostas
            </button>
          </div>
          <div className="text-center text-xs text-slate-300 font-serif max-w-sm mt-4">CANAN - Campus Ananindeua. Este relatório é de uso pessoal e confidencial. Em caso de crise, procure o Centro de Atenção Psicossocial (CAPS) ou ligue 188 (CVV).</div>
        </div>
      </div>
    </div>
  );
};

export default App;
