
import { GoogleGenAI } from "@google/genai";
import { UserResponse, PrognosisType } from "../types";
import { QUESTIONS } from "../constants";

export const analyzeEmotionalState = async (
  responses: UserResponse[],
  prognosis: PrognosisType
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const detailedResponses = responses.map(r => {
    const q = QUESTIONS.find(q => q.id === r.questionId);
    return `Questão: ${q?.text} | Resposta: ${Array.isArray(r.value) ? r.value.join(', ') : r.value}`;
  }).join('\n');

  const prompt = `
    Você é um psicólogo virtual acolhedor especializado na realidade da UFPA Ananindeua.
    Analise os resultados do "Questionário sobre Saúde Mental na Jornada Acadêmica" de um estudante.
    
    Prognóstico Calculado: ${prognosis}
    
    Respostas do Aluno:
    ${detailedResponses}
    
    Instruções:
    1. Forneça uma devolutiva humanizada, empática e encorajadora.
    2. Comente sobre pontos específicos (como fatores de impacto ou sugestões de melhoria) que o aluno citou.
    3. Mantenha um tom profissional mas acolhedor (princípios éticos de saúde).
    4. Reforce que este é um suporte inicial e que o Campus Ananindeua possui serviços presenciais.
    5. Use linguagem clara e parágrafos curtos.
    
    Retorne apenas o texto da análise.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Sua jornada acadêmica é importante. Continue buscando o equilíbrio e o autoconhecimento.";
  } catch (error) {
    console.error("AI Error:", error);
    return "Ocorreu um erro na análise, mas o seu resultado indica: " + prognosis + ". Recomendamos uma conversa com o suporte psicológico do campus.";
  }
};
